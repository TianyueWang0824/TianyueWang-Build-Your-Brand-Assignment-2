# Tianyue Wang - Personal Portfolio

Personal portfolio website for the Rutgers Business School Personal Portfolio Website assignment.

## Student

Tianyue Wang  
Rutgers Business School  
Junior  
Major: Supply Chain Management

## Files

- `index.html` - Main portfolio website
- `style.css` - Website styling

## GitHub Pages

Repository Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save
